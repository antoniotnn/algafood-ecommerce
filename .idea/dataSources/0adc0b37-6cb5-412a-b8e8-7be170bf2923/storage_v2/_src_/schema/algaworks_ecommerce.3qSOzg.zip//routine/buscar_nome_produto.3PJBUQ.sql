create
    definer = root@localhost procedure buscar_nome_produto(IN produto_id int, OUT produto_nome varchar(255))
begin select nome into produto_nome from produto where id = produto_id; end;

