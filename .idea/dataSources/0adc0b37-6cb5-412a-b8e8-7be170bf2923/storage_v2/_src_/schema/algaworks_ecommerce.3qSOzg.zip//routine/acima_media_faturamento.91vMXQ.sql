create
    definer = root@localhost function acima_media_faturamento(valor double) returns tinyint(1)
    return valor > (select avg(total) from pedido);

