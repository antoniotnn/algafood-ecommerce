create view view_clientes_acima_media as
select `cli`.`ID`               AS `ID`,
       `cli`.`CPF`              AS `CPF`,
       `cli`.`NOME`             AS `NOME`,
       `cli`.`VERSAO`           AS `VERSAO`,
       `clid`.`cliente_id`      AS `cliente_id`,
       `clid`.`data_nascimento` AS `data_nascimento`,
       `clid`.`SEXO`            AS `SEXO`
from ((`algaworks_ecommerce`.`cliente` `cli` join `algaworks_ecommerce`.`cliente_detalhe` `clid` on ((`clid`.`cliente_id` = `cli`.`ID`)))
         join `algaworks_ecommerce`.`pedido` `ped` on ((`ped`.`cliente_id` = `cli`.`ID`)))
where ((`ped`.`STATUS` = 'PAGO') and (year(`ped`.`data_criacao`) = year(curdate())))
group by `ped`.`cliente_id`
having (sum(`ped`.`TOTAL`) >= (select avg(`total_por_cliente`.`sum_total`)
                               from (select sum(`ped2`.`TOTAL`) AS `sum_total`
                                     from `algaworks_ecommerce`.`pedido` `ped2`
                                     where ((`ped2`.`STATUS` = 'PAGO') and
                                            (year(`ped2`.`data_criacao`) = year(curdate())))
                                     group by `ped2`.`cliente_id`) `total_por_cliente`));

