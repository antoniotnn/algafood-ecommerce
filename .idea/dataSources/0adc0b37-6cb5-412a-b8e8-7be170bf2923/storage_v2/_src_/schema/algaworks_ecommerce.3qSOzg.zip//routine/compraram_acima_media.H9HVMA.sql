create
    definer = root@localhost procedure compraram_acima_media(IN ano int)
begin select cli.*, clid.* from cliente cli join cliente_detalhe clid on clid.cliente_id = cli.id join pedido ped on ped.cliente_id = cli.id where ped.status = 'PAGO' and year(ped.data_criacao) = ano group by ped.cliente_id having sum(ped.total) >= (select avg(total_por_cliente.sum_total) from (select sum(ped2.total) sum_total from pedido ped2 where ped2.status = 'PAGO' and year(ped2.data_criacao) = ano group by ped2.cliente_id) as total_por_cliente); end;

