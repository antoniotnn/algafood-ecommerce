create
    definer = root@localhost procedure ajustar_preco_produto(IN produto_id int, IN percentual_ajuste double,
                                                             OUT preco_ajustado double)
begin declare produto_preco double; select preco into produto_preco from produto where id = produto_id; set preco_ajustado = produto_preco + (produto_preco * percentual_ajuste); update produto set preco = preco_ajustado where id = produto_id; end;

